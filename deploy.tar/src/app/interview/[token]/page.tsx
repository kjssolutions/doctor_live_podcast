import { notFound } from "next/navigation";

import { InterviewRecorderLoader } from "@/app/interview/[token]/interview-recorder-loader";
import { getActiveQuestions, getDoctorByInterviewToken } from "@/lib/interviews";
import { prisma } from "@/lib/prisma";
import { normalizeStorageUrlForDb } from "@/lib/spaces";
import { formatDoctorDisplayName } from "@/lib/validations";

export const dynamic = "force-dynamic";

export default async function PublicInterviewPage({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  const doctor = await getDoctorByInterviewToken(token);

  if (!doctor) {
    notFound();
  }

  if (doctor.expiresAt && doctor.expiresAt < new Date()) {
    await prisma.doctor.update({
      where: { id: doctor.id },
      data: { interviewStatus: "EXPIRED" },
    });

    return (
      <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6 text-center">
        <h1 className="text-3xl font-bold text-slate-900">This link has expired</h1>
        <p className="mt-4 text-slate-500">
          Please ask your MR contact to create a new podcast interview link.
        </p>
      </main>
    );
  }

  if (!doctor.openedAt && doctor.interviewStatus !== "COMPLETED") {
    await prisma.doctor.update({
      where: { id: doctor.id },
      data: { interviewStatus: "OPENED", openedAt: new Date() },
    });
  }

  const questions = await getActiveQuestions();

  if (questions.length === 0) {
    return (
      <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center px-6 text-center">
        <h1 className="text-3xl font-bold text-slate-900">Interview not ready</h1>
        <p className="mt-4 text-slate-500">
          No active questions are configured. Run npm run db:setup-local and npm
          run prisma:seed.
        </p>
      </main>
    );
  }

  const completedQuestionIds = doctor.recordings.map(
    (recording) => recording.questionId,
  );

  return (
    <InterviewRecorderLoader
      completedQuestionIds={completedQuestionIds}
      doctor={{
        name: doctor.doctorName
          ? formatDoctorDisplayName(doctor.doctorName)
          : doctor.doctorCode,
        specialty: doctor.specialty,
        imageUrl: doctor.imageUrl
          ? normalizeStorageUrlForDb(doctor.imageUrl)
          : null,
      }}
      questions={questions.map((question) => ({
        id: question.id,
        title: question.title,
        prompt: question.prompt,
        order: question.order,
        avatarVideoUrl: question.avatarVideoUrl,
      }))}
      token={token}
    />
  );
}
