import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { z } from "zod";

import { prisma } from "@/lib/prisma";
import { normalizeAppRole } from "@/lib/roles";

// Local tunnels (loca.lt/ngrok) forward requests with their public host.
// NextAuth v4 only trusts that host when this flag is set.
process.env.AUTH_TRUST_HOST ??= "true";

const credentialsSchema = z.object({
  username: z.string().min(1),
  password: z.string().min(1),
});

type EmployeeAuthRow = {
  empEmployeeId: string;
  empName: string | null;
  empDesignation: string | null;
  empUsername: string;
  empPassword: string;
  role: string | null;
};

async function findEmployeeForAuth(username: string): Promise<EmployeeAuthRow | null> {
  const normalized = username.trim();

  const employee = await prisma.employee.findFirst({
    where: {
      OR: [{ empUsername: normalized }, { empEmployeeId: normalized }],
    },
    select: {
      empEmployeeId: true,
      empName: true,
      empDesignation: true,
      empUsername: true,
      empPassword: true,
      role: true,
    },
  });

  if (employee) {
    return employee;
  }

  // Backward compatibility: some DBs still use legacy `employee_table`.
  try {
    const legacyRows = await prisma.$queryRaw<EmployeeAuthRow[]>`
      SELECT
        emp_employee_id AS empEmployeeId,
        emp_name AS empName,
        emp_designation AS empDesignation,
        emp_username AS empUsername,
        emp_password AS empPassword,
        NULL AS role
      FROM employee_table
      WHERE emp_username = ${normalized} OR emp_employee_id = ${normalized}
      LIMIT 1
    `;

    return legacyRows[0] ?? null;
  } catch {
    return null;
  }
}

export const authOptions: NextAuthOptions = {
  session: {
    strategy: "jwt",
  },
  secret:
    process.env.NEXTAUTH_SECRET ??
    (process.env.NODE_ENV === "development" ? "dev-secret-change-me" : undefined),
  pages: {
    signIn: "/login",
  },
  providers: [
    CredentialsProvider({
      name: "Employee Login",
      credentials: {
        username: { label: "Employee ID", type: "text" },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const parsed = credentialsSchema.safeParse(credentials);

        if (!parsed.success) {
          return null;
        }

        const employee = await findEmployeeForAuth(parsed.data.username);

        if (!employee) {
          return null;
        }

        if (employee.empPassword !== parsed.data.password) {
          return null;
        }

        const role = normalizeAppRole(employee.role, employee.empDesignation);

        return {
          id: employee.empEmployeeId,
          name: employee.empName ?? employee.empUsername,
          email: employee.empUsername,
          role,
        };
      },
    }),
  ],
  callbacks: {
    jwt({ token, user }) {
      if (user) {
        token.id = user.id;
        token.role = user.role;
      }

      return token;
    },
    session({ session, token }) {
      if (session.user) {
        session.user.id = token.id as string;
        session.user.role = token.role as typeof session.user.role;
      }

      return session;
    },
  },
};
